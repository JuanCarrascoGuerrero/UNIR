/*import { IUser } from "../interfaces/iuser.interface";

export const USERS : IUser[] = [
    {
    imgsrc: 'https://randomuser.me/api/portraits/men/11.jpg',
    nombre: 'Andrés',
    apellido: 'Morales',
    username: 'andresm',
    email: 'andres.morales@example.com'
  },
  {
    imgsrc: 'https://randomuser.me/api/portraits/women/12.jpg',
    nombre: 'María',
    apellido: 'Castro',
    username: 'mcastro',
    email: 'maria.castro@example.com'
  },
  {
    imgsrc: 'https://randomuser.me/api/portraits/men/13.jpg',
    nombre: 'Luis',
    apellido: 'Pérez',
    username: 'lperez',
    email: 'luis.perez@example.com'
  },
  {
    imgsrc: 'https://randomuser.me/api/portraits/women/14.jpg',
    nombre: 'Ana',
    apellido: 'Ruiz',
    username: 'anaruiz',
    email: 'ana.ruiz@example.com'
  },
  {
    imgsrc: 'https://randomuser.me/api/portraits/men/15.jpg',
    nombre: 'Jorge',
    apellido: 'Navarro',
    username: 'jnavarro',
    email: 'jorge.navarro@example.com'
  },
  {
    imgsrc: 'https://randomuser.me/api/portraits/women/16.jpg',
    nombre: 'Claudia',
    apellido: 'Vega',
    username: 'claudiav',
    email: 'claudia.vega@example.com'
  },
  {
    imgsrc: 'https://randomuser.me/api/portraits/men/17.jpg',
    nombre: 'Raúl',
    apellido: 'Torres',
    username: 'rault',
    email: 'raul.torres@example.com'
  }
]*/